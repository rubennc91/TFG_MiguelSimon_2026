#!/bin/bash 
cd /home/miguel_tfg/FINN-v0.9-Stable/notebooks/UAH_example/FINN_build/code_gen_ipgen_StreamingFIFO_4_csorq8ss/project_StreamingFIFO_4/sol1/impl/verilog
vivado -mode batch -source package_ip.tcl
cd /home/miguel_tfg/FINN-v0.9-Stable
