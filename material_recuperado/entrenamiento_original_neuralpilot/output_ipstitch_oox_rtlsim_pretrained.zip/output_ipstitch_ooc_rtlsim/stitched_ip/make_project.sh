#!/bin/bash 
cd /tmp/finn_dev_nvidia/vivado_stitch_proj_4xefdhal
vivado -mode batch -source make_project.tcl
cd /home/nvidia/finn
